import { z } from 'zod';
import { createClient } from '@metagptx/web-sdk';

export const configSchema = z.object({
  schemaVersion: z.literal(1),
  type: z.enum(['todo', 'pomodoro']),
  name: z.string().min(1).max(40),
  description: z.string().min(1).max(160),
  accent: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  tasks: z.array(z.string().min(1).max(120)).max(12),
  focusMinutes: z.number().int().min(1).max(120),
  breakMinutes: z.number().int().min(1).max(60),
  buttonLabel: z.string().min(1).max(24),
});
export type AppConfig = z.infer<typeof configSchema>;
export type Version = { id: string; config: AppConfig; prompt: string; createdAt: string };
export type SavedApp = { id: string; versions: Version[]; activeVersionId: string; updatedAt: string };
export type AppVersionEntry = { appId: string; version: number; timestamp: string; description: string; spec: AppConfig };
export const exampleConfig: AppConfig = {
  schemaVersion: 1, type: 'todo', name: '今日待办', description: '让想法落地，从一件小事开始。', accent: '#21836B',
  tasks: ['整理今天的工作计划', '阅读 20 分钟', '完成 Mini App Builder 的第一个应用'], focusMinutes: 25, breakMinutes: 5, buttonLabel: '添加任务',
};
const librarySchema = z.array(z.object({
  id: z.string(), versions: z.array(z.object({ id: z.string(), config: configSchema, prompt: z.string(), createdAt: z.string() })).min(1),
  activeVersionId: z.string(), updatedAt: z.string(),
}));
const LIBRARY_KEY = 'mini-builder:library:v1';
export function readLibrary(): SavedApp[] {
  const text = localStorage.getItem(LIBRARY_KEY);
  if (!text) return [];
  return librarySchema.parse(JSON.parse(text));
}
export function writeLibrary(apps: SavedApp[]) { localStorage.setItem(LIBRARY_KEY, JSON.stringify(apps)); }
export function shareUrl(config: AppConfig) {
  const bytes = new TextEncoder().encode(JSON.stringify(config));
  const encoded = btoa(Array.from(bytes, byte => String.fromCharCode(byte)).join('')).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  return `${window.location.origin}${window.location.pathname}#/share?app=${encoded}`;
}
export function readShared(): AppConfig | null {
  const raw = window.location.hash.replace(/^#/, '');
  const query = raw.startsWith('/share?') ? raw.slice('/share?'.length) : raw;
  const encoded = new URLSearchParams(query).get('app');
  if (!encoded) return null;
  if (encoded.length > 16000) throw new Error('分享链接过长或已损坏。');
  const bytes = Uint8Array.from(atob(encoded.replace(/-/g, '+').replace(/_/g, '/')), char => char.charCodeAt(0));
  return configSchema.parse(JSON.parse(new TextDecoder().decode(bytes)));
}
const SHARED_KEY = 'mini-builder:shared';
export function storeShared(config: AppConfig) { try { sessionStorage.setItem(SHARED_KEY, JSON.stringify(config)); } catch { /* 会话存储不可用时忽略 */ } }
export function readStoredShared(): AppConfig | null { try { const text = sessionStorage.getItem(SHARED_KEY); return text ? configSchema.parse(JSON.parse(text)) : null; } catch { return null; } }
export function clearStoredShared() { try { sessionStorage.removeItem(SHARED_KEY); } catch { /* 忽略 */ } }
const APP_VERSIONS_KEY = 'appVersions';
const appVersionSchema = z.object({ appId: z.string(), version: z.number().int().min(1), timestamp: z.string(), description: z.string(), spec: configSchema });
export function readAppVersions(): AppVersionEntry[] {
  try { const text = localStorage.getItem(APP_VERSIONS_KEY); if (!text) return []; return z.array(appVersionSchema).parse(JSON.parse(text)); } catch { return []; }
}
export function rebuildAppVersions(library: SavedApp[]): AppVersionEntry[] {
  const entries = library.flatMap(app => app.versions.map((version, index) => ({ appId: app.id, version: index + 1, timestamp: version.createdAt, description: version.prompt || '初始版本', spec: version.config })));
  try { localStorage.setItem(APP_VERSIONS_KEY, JSON.stringify(entries)); } catch { /* 存储不可用时面板仍显示会话内数据 */ }
  return entries;
}
const client = createClient();
export async function generateApp(prompt: string, current?: AppConfig) {
  const response = await client.apiCall.invoke({ url: '/api/v1/builder/generate', method: 'POST', data: { prompt, current: current ?? null }, options: { timeout: 600_000 } });
  return configSchema.parse(response.data.config);
}
export function errorMessage(error: unknown): string {
  const details = error as { data?: { detail?: unknown }; response?: { data?: { detail?: unknown } }; message?: string };
  const detail = details?.data?.detail ?? details?.response?.data?.detail;
  if (typeof detail === 'string') return detail;
  return details?.message || '操作失败，请重试。';
}
