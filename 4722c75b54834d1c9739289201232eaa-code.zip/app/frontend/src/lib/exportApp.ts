import type { AppConfig } from '@/lib/builder';

function escapeHtml(value: string): string {
  return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function scriptJson(value: unknown): string { return JSON.stringify(value).replace(/</g, '\\u003c'); }
function two(n: number): string { return String(n).padStart(2, '0'); }
function timestamp(): string {
  const d = new Date();
  return `${d.getFullYear()}${two(d.getMonth() + 1)}${two(d.getDate())}_${two(d.getHours())}${two(d.getMinutes())}${two(d.getSeconds())}`;
}
export function exportFileName(config: AppConfig): string {
  const safe = config.name.replace(/\s+/g, '_').replace(/[\\/:*?"<>|]/g, '').trim() || 'MiniApp';
  return `${safe}_${timestamp()}`;
}

const SHARED_CSS = `*{box-sizing:border-box}body{margin:0;min-height:100vh;display:flex;justify-content:center;align-items:flex-start;padding:24px 16px;background:#f8fbf9;color:#34473e;font-family:Arial,'PingFang SC','Microsoft YaHei',sans-serif;font-size:14px;line-height:1.6}.app{width:100%;max-width:480px;background:#fff;border:1px solid #e7ece9;border-radius:12px;padding:24px 22px;box-shadow:0 12px 32px rgba(35,38,45,.05)}.symbol{width:46px;height:46px;display:grid;place-items:center;border-radius:12px;color:var(--accent);background:color-mix(in srgb,var(--accent) 10%,#fff);margin-bottom:14px}h1{font-size:22px;margin:0;letter-spacing:-.5px;color:#2d4036}.desc{margin:6px 0 22px;color:#97a49c;font-size:12px}.footer{display:flex;align-items:center;justify-content:center;gap:6px;margin-top:22px;color:#a2afa7;font-size:11px}.dot{width:5px;height:5px;border-radius:50%;background:var(--cent,.5)}.dot{background:var(--accent)}`;
const TODO_CSS = `.summary{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:#96a39c}.summary b{color:var(--accent);font-weight:600}.progress{height:5px;background:#eff3f0;border-radius:4px;margin:8px 0 18px;overflow:hidden}.progress span{display:block;height:100%;width:0;background:var(--accent);border-radius:4px;transition:width .15s ease}.add{display:flex;gap:6px;border:1px solid #e0e7e2;border-radius:8px;padding:5px;background:#fff}.add input{flex:1;min-width:0;border:0;outline:0;padding:8px;font:inherit;font-size:13px;color:#34473e;background:transparent}.add button{width:36px;border:0;border-radius:6px;background:var(--accent);color:#fff;font-size:20px;cursor:pointer}.tabs{display:flex;gap:16px;margin:16px 0 6px;border-bottom:1px solid #edf1ee;padding-bottom:9px}.tabs button{border:0;background:none;padding:5px 2px;color:#9aaba1;font:inherit;font-size:12px;cursor:pointer}.tabs button.selected{color:var(--accent);font-weight:600}.tabs span{font-size:10px;background:#eff4f0;border-radius:3px;padding:1px 5px}.task{display:flex;align-items:center;gap:9px;padding:11px 0;border-bottom:1px solid #f0f3f1}.task .text{flex:1;min-width:0;word-break:break-word;font-size:13px}.task.done .text{text-decoration:line-through;color:#a5b0aa}.check{width:19px;height:19px;flex-shrink:0;display:grid;place-items:center;border:1px solid #d1dbd5;border-radius:5px;background:#fff;color:transparent;cursor:pointer;font-size:11px;line-height:1}.task.done .check{background:var(--accent);border-color:var(--accent);color:#fff}.act{border:0;background:none;color:#adb9b1;cursor:pointer;font-size:12px;padding:3px 4px}.act:hover{color:var(--accent)}.edit{display:flex;gap:5px;flex:1;min-width:0}.edit input{flex:1;min-width:0;border:1px solid #d1dbd5;border-radius:5px;padding:5px 7px;font:inherit;font-size:12px;outline:0}.edit .primary{border:0;background:var(--accent);color:#fff;border-radius:5px;padding:5px 11px;cursor:pointer;font-size:12px}.edit .cancel{border:0;background:none;color:#9aaba1;cursor:pointer;font-size:12px}.empty{padding:22px 0;text-align:center;color:#a0aaa4;font-size:12px}`;
const POMODORO_CSS = `.center{text-align:center}.center .symbol{margin:0 auto 14px}.mtabs{display:inline-flex;gap:4px;background:#f4f6f4;border-radius:8px;padding:3px}.mtabs button{border:0;background:none;padding:8px 16px;border-radius:6px;color:#94a198;font:inherit;font-size:13px;cursor:pointer}.mtabs button.selected{background:#fff;color:var(--accent);font-weight:600}.face{padding:32px 0}.face .clock{display:block;font-family:Consolas,'SFMono-Regular',monospace;font-size:58px;letter-spacing:-3px;color:var(--accent)}.face small{display:block;margin-top:10px;color:#94a198;font-size:12px}.controls{display:flex;gap:10px;justify-content:center;margin-bottom:18px}.controls button{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:44px;padding:10px 20px;border:0;border-radius:8px;background:#f3f5f3;color:var(--accent);font:inherit;font-size:14px;font-weight:600;cursor:pointer}.controls .primary{background:var(--accent);color:#fff;min-width:150px}.controls button:disabled{opacity:.5;cursor:not-allowed}.meta{color:#a2afa7;font-size:12px}`;

const TODO_ICON = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6h12M9 12h12M9 18h12"/><path d="m3 5 1.5 1.5L7 4"/><path d="m3 11 1.5 1.5L7 10"/><path d="m3 17 1.5 1.5L7 16"/></svg>';
const TIMER_ICON = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2"/><path d="M9 2h6"/></svg>';

function todoBody(config: AppConfig): string {
  return `<div class="app">
  <div class="symbol">${TODO_ICON}</div>
  <h1>${escapeHtml(config.name)}</h1>
  <p class="desc">${escapeHtml(config.description)}</p>
  <div class="summary"><span>今天也在一点点进步</span><b id="count">0 / 0 已完成</b></div>
  <div class="progress"><span id="bar"></span></div>
  <form id="add-form" class="add"><input id="add-input" type="text" maxlength="120" placeholder="接下来想做什么？" autocomplete="off"><button type="submit" aria-label="${escapeHtml(config.buttonLabel)}">+</button></form>
  <div class="tabs" id="tabs"><button type="button" class="selected" data-filter="all">全部 <span id="c-all">0</span></button><button type="button" data-filter="active">待完成</button><button type="button" data-filter="done">已完成</button></div>
  <div id="tasks"></div>
  <div class="footer"><span class="dot"></span><span>由 Mini App Builder 导出 · ${escapeHtml(config.name)}</span></div>
</div>`;
}
function todoScript(config: AppConfig): string {
  return `var INITIAL_TASKS = ${scriptJson(config.tasks)};
var tasks = INITIAL_TASKS.map(function (text, i) { return { id: i, text: text, done: false }; });
var filter = 'all';
var editingId = null;
var listEl = document.getElementById('tasks');
var barEl = document.getElementById('bar');
var countEl = document.getElementById('count');
var cAll = document.getElementById('c-all');
function render() {
  var done = tasks.filter(function (t) { return t.done; }).length;
  barEl.style.width = (tasks.length ? done / tasks.length * 100 : 0) + '%';
  countEl.textContent = done + ' / ' + tasks.length + ' 已完成';
  cAll.textContent = String(tasks.length);
  document.querySelectorAll('#tabs button').forEach(function (b) { b.classList.toggle('selected', b.dataset.filter === filter); });
  var visible = tasks.filter(function (t) { return filter === 'all' || (filter === 'done' ? t.done : !t.done); });
  listEl.innerHTML = '';
  if (!visible.length) {
    var p = document.createElement('p');
    p.className = 'empty';
    p.textContent = filter === 'done' ? '完成第一项任务，给自己一个小小的鼓励。' : '这里很清爽，添加一项新的任务吧。';
    listEl.appendChild(p);
    return;
  }
  visible.forEach(function (task) {
    var row = document.createElement('div');
    row.className = 'task' + (task.done ? ' done' : '');
    var check = document.createElement('button');
    check.type = 'button'; check.className = 'check'; check.textContent = '✓';
    check.setAttribute('aria-label', '完成 ' + task.text);
    check.onclick = function () { task.done = !task.done; render(); };
    row.appendChild(check);
    if (editingId === task.id) {
      var form = document.createElement('form'); form.className = 'edit';
      var input = document.createElement('input'); input.value = task.text; input.maxLength = 120;
      var save = document.createElement('button'); save.type = 'submit'; save.className = 'primary'; save.textContent = '保存';
      var cancel = document.createElement('button'); cancel.type = 'button'; cancel.className = 'cancel'; cancel.textContent = '取消';
      cancel.onclick = function () { editingId = null; render(); };
      form.onsubmit = function (e) { e.preventDefault(); var v = input.value.trim(); if (v) { task.text = v; editingId = null; render(); } };
      form.appendChild(input); form.appendChild(save); form.appendChild(cancel); row.appendChild(form);
    } else {
      var span = document.createElement('span'); span.className = 'text'; span.textContent = task.text; row.appendChild(span);
      var edit = document.createElement('button'); edit.type = 'button'; edit.className = 'act'; edit.textContent = '编辑';
      edit.onclick = function () { editingId = task.id; render(); };
      var del = document.createElement('button'); del.type = 'button'; del.className = 'act'; del.textContent = '删除';
      del.onclick = function () { tasks = tasks.filter(function (t) { return t !== task; }); render(); };
      row.appendChild(edit); row.appendChild(del);
    }
    listEl.appendChild(row);
  });
}
document.getElementById('add-form').addEventListener('submit', function (e) {
  e.preventDefault();
  var input = document.getElementById('add-input');
  var v = input.value.trim();
  if (!v) return;
  tasks.push({ id: Date.now(), text: v, done: false });
  input.value = '';
  render();
});
document.getElementById('tabs').addEventListener('click', function (e) {
  var b = e.target.closest('button');
  if (!b) return;
  filter = b.dataset.filter;
  render();
});
render();`;
}
function pomodoroBody(config: AppConfig): string {
  return `<div class="app center">
  <div class="symbol">${TIMER_ICON}</div>
  <h1>${escapeHtml(config.name)}</h1>
  <p class="desc">${escapeHtml(config.description)}</p>
  <div class="mtabs" id="modes"><button type="button" class="selected" data-mode="focus">专注时间</button><button type="button" data-mode="break">短暂休息</button></div>
  <div class="face"><span class="clock" id="clock">25:00</span><small id="hint">准备好，给自己一段专注时间</small></div>
  <div class="controls"><button type="button" class="primary" id="toggle">${escapeHtml(config.buttonLabel)}</button><button type="button" id="reset">重置</button></div>
  <div class="meta">专注 ${config.focusMinutes} 分钟 · 休息 ${config.breakMinutes} 分钟</div>
  <div class="footer"><span class="dot"></span><span>由 Mini App Builder 导出</span></div>
</div>`;
}
function pomodoroScript(config: AppConfig): string {
  return `var FOCUS = ${config.focusMinutes} * 60;
var BREAK = ${config.breakMinutes} * 60;
var START_LABEL = ${scriptJson(config.buttonLabel)};
var mode = 'focus';
var remaining = FOCUS;
var timer = null;
var clockEl = document.getElementById('clock');
var hintEl = document.getElementById('hint');
var toggleBtn = document.getElementById('toggle');
function two(n) { return String(n).padStart(2, '0'); }
function render() {
  clockEl.textContent = two(Math.floor(remaining / 60)) + ':' + two(remaining % 60);
  var running = !!timer;
  toggleBtn.textContent = running ? '暂停' : START_LABEL;
  toggleBtn.disabled = !running && remaining === 0;
  hintEl.textContent = remaining === 0 ? '本轮完成，休息一下吧！' : running ? '保持专注，你正在前进' : '准备好，给自己一段专注时间';
  document.querySelectorAll('#modes button').forEach(function (b) { b.classList.toggle('selected', b.dataset.mode === mode); });
}
function stop() { if (timer) { clearInterval(timer); timer = null; } }
toggleBtn.onclick = function () {
  if (timer) { stop(); render(); return; }
  timer = setInterval(function () { remaining -= 1; if (remaining <= 0) { remaining = 0; stop(); } render(); }, 1000);
  render();
};
document.getElementById('reset').onclick = function () { stop(); remaining = mode === 'focus' ? FOCUS : BREAK; render(); };
document.getElementById('modes').addEventListener('click', function (e) {
  var b = e.target.closest('button');
  if (!b) return;
  stop();
  mode = b.dataset.mode;
  remaining = mode === 'focus' ? FOCUS : BREAK;
  render();
});
render();`;
}
export function buildStandaloneHtml(config: AppConfig): string {
  const body = config.type === 'pomodoro' ? pomodoroBody(config) : todoBody(config);
  const script = config.type === 'pomodoro' ? pomodoroScript(config) : todoScript(config);
  const extraCss = config.type === 'pomodoro' ? POMODORO_CSS : TODO_CSS;
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(config.name)}</title>
<style>
:root { --accent: ${config.accent}; }
${SHARED_CSS}
${extraCss}
</style>
</head>
<body>
${body}
<script>
${script}
</script>
</body>
</html>`;
}
export function exportAppHtml(config: AppConfig): string {
  const fileName = exportFileName(config) + '.html';
  const blob = new Blob([buildStandaloneHtml(config)], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  return fileName;
}
