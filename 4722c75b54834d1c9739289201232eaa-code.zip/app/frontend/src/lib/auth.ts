export const DEMO_ACCOUNT = { email: 'test@atoms-demo.com', password: 'Demo123456' } as const;

export function readAuth() {
  try {
    return { isLogin: localStorage.getItem('isLogin') === 'true', userEmail: localStorage.getItem('userEmail') || '' };
  } catch {
    return { isLogin: false, userEmail: '' };
  }
}

export function saveLogin(email: string) {
  try {
    localStorage.setItem('isLogin', 'true');
    localStorage.setItem('userEmail', email);
  } catch {
    /* 极少数隐私模式写入失败：登录状态仅保留在当前页面 */
  }
}

export function clearLogin() {
  try {
    localStorage.removeItem('isLogin');
    localStorage.removeItem('userEmail');
  } catch {
    /* 忽略清理失败 */
  }
}
