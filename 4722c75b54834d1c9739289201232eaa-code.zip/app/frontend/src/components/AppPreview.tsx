import { useEffect, useState, type CSSProperties } from 'react';
import { Check, Plus, Trash2, Pencil, ListTodo, Timer, Play, Pause, RotateCcw } from 'lucide-react';
import { z } from 'zod';
import type { AppConfig } from '@/lib/builder';

type Task = { id: string; text: string; done: boolean };
const taskSchema = z.array(z.object({ id: z.string(), text: z.string().min(1).max(120), done: z.boolean() }));
const timerSchema = z.object({ mode: z.enum(['focus', 'break']), remaining: z.number().min(0).max(7200), deadline: z.number().nullable() });
function useStored<T>(key: string, initial: T, schema: z.ZodType<T>, onError: (message: string) => void) {
  const [value, setValue] = useState<T>(() => {
    try { const text = localStorage.getItem(key); return text ? schema.parse(JSON.parse(text)) : initial; }
    catch { return initial; }
  });
  useEffect(() => {
    try { localStorage.setItem(key, JSON.stringify(value)); }
    catch { onError('浏览器无法保存预览操作，请检查本地存储空间或隐私设置。'); }
  }, [key, value, onError]);
  return [value, setValue] as const;
}
function TodoPreview({ config, storageKey, onError }: PreviewProps) {
  const [tasks, setTasks] = useStored<Task[]>(`${storageKey}:tasks`, config.tasks.map((text, index) => ({ id: `initial-${index}`, text, done: false })), taskSchema, onError);
  const [text, setText] = useState('');
  const [filter, setFilter] = useState('全部');
  const [editing, setEditing] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const completed = tasks.filter(task => task.done).length;
  const filtered = tasks.filter(task => filter === '全部' || (filter === '已完成' ? task.done : !task.done));
  function addTask(event: React.FormEvent) {
    event.preventDefault();
    if (!text.trim()) return;
    if (tasks.length >= 100) { onError('单个清单最多保存 100 项任务。'); return; }
    setTasks([...tasks, { id: crypto.randomUUID(), text: text.trim(), done: false }]); setText('');
  }
  function saveEdit(event: React.FormEvent) {
    event.preventDefault(); if (!editText.trim()) return;
    setTasks(tasks.map(task => task.id === editing ? { ...task, text: editText.trim() } : task)); setEditing(null);
  }
  return <div className="mini-app" style={{ '--app-accent': config.accent } as CSSProperties}>
    <div className="app-symbol"><ListTodo size={24} /></div><h2>{config.name}</h2><p className="app-description">{config.description}</p>
    <div className="task-summary"><span>今天也在一点点进步</span><b>{completed} / {tasks.length} 已完成</b></div>
    <div className="task-progress"><span style={{ width: `${tasks.length ? completed / tasks.length * 100 : 0}%` }} /></div>
    <form className="add-task" onSubmit={addTask}><input aria-label="新任务" placeholder="接下来想做什么？" maxLength={120} value={text} onChange={event => setText(event.target.value)} /><button title={config.buttonLabel} aria-label={config.buttonLabel} disabled={!text.trim()}><Plus size={18} /></button></form>
    <div className="task-tabs">{['全部', '待完成', '已完成'].map(label => <button key={label} className={filter === label ? 'selected' : ''} onClick={() => setFilter(label)}>{label}{label === '全部' && <span>{tasks.length}</span>}</button>)}</div>
    <div className="tasks">{filtered.map(task => <div className={`task-row ${task.done ? 'done' : ''}`} key={task.id}>
      <button className="task-check" role="checkbox" aria-checked={task.done} aria-label={`完成 ${task.text}`} onClick={() => setTasks(tasks.map(item => item.id === task.id ? { ...item, done: !item.done } : item))}>{task.done && <Check size={13} />}</button>
      {editing === task.id ? <form className="task-edit" onSubmit={saveEdit}><input aria-label="编辑任务" autoFocus maxLength={120} value={editText} onChange={event => setEditText(event.target.value)} /><button aria-label="保存编辑"><Check size={15} /></button><button type="button" onClick={() => setEditing(null)}>取消</button></form> : <><span>{task.text}</span><button className="task-action" aria-label={`编辑 ${task.text}`} onClick={() => { setEditing(task.id); setEditText(task.text); }}><Pencil size={13} /></button><button className="task-action" aria-label={`删除 ${task.text}`} onClick={() => setTasks(tasks.filter(item => item.id !== task.id))}><Trash2 size={13} /></button></>}
    </div>)}{filtered.length === 0 && <p className="task-empty">{filter === '已完成' ? '完成第一项任务，给自己一个小小的鼓励。' : '这里很清爽，添加一项新的任务吧。'}</p>}</div>
    <div className="app-footer"><span className="tiny-dot" />已在当前浏览器保存 <span>一步一步，慢慢来。</span></div>
  </div>;
}
function PomodoroPreview({ config, storageKey, onError }: PreviewProps) {
  const [timer, setTimer] = useStored(`${storageKey}:timer`, { mode: 'focus' as 'focus' | 'break', remaining: config.focusMinutes * 60, deadline: null as number | null }, timerSchema, onError);
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!timer.deadline) return;
    const tick = () => {
      const time = Date.now(); setNow(time);
      if (timer.deadline && time >= timer.deadline) setTimer(previous => ({ ...previous, remaining: 0, deadline: null }));
    };
    tick(); const interval = window.setInterval(tick, 250); return () => clearInterval(interval);
  }, [timer.deadline, setTimer]);
  const seconds = timer.deadline ? Math.max(0, Math.ceil((timer.deadline - now) / 1000)) : timer.remaining;
  function changeMode(mode: 'focus' | 'break') { setTimer({ mode, remaining: (mode === 'focus' ? config.focusMinutes : config.breakMinutes) * 60, deadline: null }); }
  function toggle() {
    if (timer.deadline) setTimer({ ...timer, remaining: Math.max(0, Math.ceil((timer.deadline - Date.now()) / 1000)), deadline: null });
    else { setNow(Date.now()); setTimer({ ...timer, deadline: Date.now() + seconds * 1000 }); }
  }
  return <div className="mini-app timer-app" style={{ '--app-accent': config.accent } as CSSProperties}><div className="app-symbol"><Timer size={24} /></div><h2>{config.name}</h2><p className="app-description">{config.description}</p>
    <div className="timer-tabs">{(['focus', 'break'] as const).map(mode => <button key={mode} className={timer.mode === mode ? 'selected' : ''} onClick={() => changeMode(mode)}>{mode === 'focus' ? '专注时间' : '短暂休息'}</button>)}</div>
    <div className="timer-face"><span>{String(Math.floor(seconds / 60)).padStart(2, '0')}<em>:</em>{String(seconds % 60).padStart(2, '0')}</span><small>{seconds === 0 ? '本轮完成，休息一下吧！' : timer.deadline ? '保持专注，你正在前进' : '准备好，给自己一段专注时间'}</small></div>
    <div className="timer-controls"><button className="timer-primary" onClick={toggle} disabled={seconds === 0}>{timer.deadline ? <Pause size={17} /> : <Play size={17} />}{timer.deadline ? '暂停' : config.buttonLabel}</button><button aria-label="重置计时" onClick={() => changeMode(timer.mode)}><RotateCcw size={18} /></button></div><div className="app-footer">专注 {config.focusMinutes} 分钟 · 休息 {config.breakMinutes} 分钟</div>
  </div>;
}
type PreviewProps = { config: AppConfig; storageKey: string; onError: (message: string) => void };
export default function AppPreview(props: PreviewProps) { return props.config.type === 'todo' ? <TodoPreview {...props} /> : <PomodoroPreview {...props} />; }
