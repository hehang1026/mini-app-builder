import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function BackHomeButton() {
  const navigate = useNavigate();
  return (
    <button type="button" className="nav-btn ghost-nav back-home-btn" onClick={() => navigate('/')}>
      <ArrowLeft size={14} />
      返回主页面
    </button>
  );
}
