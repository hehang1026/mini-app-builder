import type { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';

export default function ProtectedRoute({ children }: { children: ReactNode }) {
  if (localStorage.getItem('isLogin') !== 'true') return <Navigate to="/login" replace />;
  return <>{children}</>;
}
