import { useState, type FormEvent } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { AlertCircle, Box, Info, Loader2, UserPlus } from 'lucide-react';
import { toast } from 'sonner';
import { readAuth } from '@/lib/auth';
import BackHomeButton from '@/components/BackHomeButton';

export default function Register() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  if (readAuth().isLogin) return <Navigate to="/" replace />;

  function submit(event: FormEvent) {
    event.preventDefault();
    if (submitting) return;
    const trimmed = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) { setError('请输入有效的邮箱地址'); return; }
    if (password.length < 6) { setError('密码至少需要 6 位'); return; }
    if (password !== confirm) { setError('两次输入的密码不一致'); return; }
    setError(''); setSubmitting(true);
    window.setTimeout(() => {
      setSubmitting(false);
      toast.success('注册成功（演示环境，未创建真实账号）');
      navigate('/login', { replace: true });
    }, 600);
  }

  return (
    <div className="login-shell">
      <BackHomeButton />
      <div className="login-brand"><span className="brand-mark"><Box size={22} strokeWidth={1.8} /></span><strong>Mini App Builder</strong></div>
      <main className="login-card">
        <h1>创建你的账号</h1>
        <p className="login-sub">演示注册，填写信息即可体验完整流程。</p>
        {error && <div className="login-error" role="alert"><AlertCircle size={15} />{error}</div>}
        <form onSubmit={submit}>
          <div className="login-field">
            <label className="field-label" htmlFor="register-email">邮箱</label>
            <input id="register-email" className="login-input" type="email" autoComplete="email" placeholder="you@example.com" value={email} disabled={submitting} onChange={event => setEmail(event.target.value)} />
          </div>
          <div className="login-field">
            <label className="field-label" htmlFor="register-password">密码</label>
            <input id="register-password" className="login-input" type="password" autoComplete="new-password" placeholder="至少 6 位" value={password} disabled={submitting} onChange={event => setPassword(event.target.value)} />
          </div>
          <div className="login-field">
            <label className="field-label" htmlFor="register-confirm">确认密码</label>
            <input id="register-confirm" className="login-input" type="password" autoComplete="new-password" placeholder="再次输入密码" value={confirm} disabled={submitting} onChange={event => setConfirm(event.target.value)} />
          </div>
          <button className="primary-btn login-submit" type="submit" disabled={submitting}>{submitting ? <Loader2 size={16} className="spin" /> : <UserPlus size={16} />}{submitting ? '注册中…' : '注册'}</button>
        </form>
        <div className="demo-hint"><Info size={14} /><span>演示注册：不会创建真实账号。登录请使用测试账号 test@atoms-demo.com / Demo123456。</span></div>
        <p className="login-alt">已有账号？<Link to="/login">直接登录</Link></p>
      </main>
      <p className="login-footer">本地演示 · 数据仅保存在当前浏览器</p>
    </div>
  );
}
