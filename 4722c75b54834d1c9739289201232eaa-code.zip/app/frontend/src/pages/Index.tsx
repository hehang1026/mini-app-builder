import { useCallback, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AlertCircle, Box, Sparkles, Plus, ArrowUpRight, ListTodo, Timer, History, ChevronRight, Save, Share2, Code2, Download, Monitor, Smartphone, Copy, Check, Loader2, RotateCcw, X, CircleHelp, FileJson, CheckCircle2, ArrowRight, LogOut, CircleUserRound, Lock } from 'lucide-react';
import { clearLogin, readAuth } from '@/lib/auth';
import { toast } from 'sonner';
import AppPreview from '@/components/AppPreview';
import { exportAppHtml } from '@/lib/exportApp';
import { clearStoredShared, exampleConfig, generateApp, readAppVersions, readLibrary, readShared, readStoredShared, rebuildAppVersions, storeShared, writeLibrary, shareUrl, errorMessage, type AppVersionEntry, type SavedApp, type Version, type AppConfig } from '@/lib/builder';

function makeVersion(config: AppConfig, prompt: string): Version { return { id: crypto.randomUUID(), config, prompt, createdAt: new Date().toISOString() }; }
function formatVersionTime(iso: string) { try { return new Date(iso).toLocaleString('zh-CN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); } catch { return iso; } }
function initialize() {
  let warning = ''; let library: SavedApp[] = []; let shared: AppConfig | null = null; let sharedInvalid = false; let libraryOk = true;
  try { library = readLibrary(); } catch { warning = '本地记录无法读取，暂未覆盖原始数据；可重新生成并保存。'; libraryOk = false; }
  try { const fromLink = readShared(); if (fromLink) { shared = fromLink; storeShared(fromLink); } } catch { sharedInvalid = true; }
  if (!shared && !sharedInvalid) shared = readStoredShared();
  let last: string | null = null;
  try { last = localStorage.getItem('mini-builder:last'); } catch { warning = '浏览器本地存储不可用，保存操作可能失败。'; }
  const saved = !shared && library.find(app => app.id === last);
  const app: SavedApp = saved || { id: crypto.randomUUID(), versions: [makeVersion(shared || exampleConfig, shared ? '从分享链接打开' : '内置示例 · 做一个待办清单')], activeVersionId: '', updatedAt: new Date().toISOString() };
  if (!app.activeVersionId) app.activeVersionId = app.versions[0].id;
  const versionLog = libraryOk ? rebuildAppVersions(library) : readAppVersions();
  return { library, app, warning, shared: !!shared, sharedInvalid, versionLog, dirty: false, example: !saved && !shared };
}
function JsonEditor({ config }: { config: AppConfig }) {
  return <div className="code-lines">{JSON.stringify(config, null, 2).split('\n').map((line, index) => <div className="code-line" key={index}><span className="line-number">{index + 1}</span><code>{line.split(/("(?:[^"\\]|\\.)*")/g).map((part, partIndex, parts) => <span key={partIndex} className={part.startsWith('"') ? parts[partIndex + 1]?.trimStart().startsWith(':') ? 'json-key' : 'json-string' : 'json-other'}>{part}</span>)}</code></div>)}</div>;
}
export default function Index() {
  const [initial] = useState(initialize);
  const [library, setLibrary] = useState(initial.library);
  const [app, setApp] = useState(initial.app);
  const [dirty, setDirty] = useState(initial.dirty);
  const [isExample, setIsExample] = useState(initial.example);
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(initial.warning);
  const [device, setDevice] = useState<'desktop' | 'mobile'>('desktop');
  const [share, setShare] = useState('');
  const [copied, setCopied] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [authed, setAuthed] = useState(() => readAuth().isLogin);
  const [userEmail] = useState(() => readAuth().userEmail);
  const [sharedMode, setSharedMode] = useState(initial.shared);
  const [sharedInvalid, setSharedInvalid] = useState(initial.sharedInvalid);
  const [versionLog, setVersionLog] = useState(initial.versionLog);
  const navigate = useNavigate();
  const active = app.versions.find(version => version.id === app.activeVersionId) || app.versions[app.versions.length - 1];
  const config = active.config;
  const versionIndex = app.versions.findIndex(version => version.id === active.id) + 1;
  const notifyStorageError = useCallback((message: string) => toast.error(message, { id: 'storage-error' }), []);
  const isSaved = !dirty && library.some(item => item.id === app.id);
  const appVersionEntries = versionLog.filter(entry => entry.appId === app.id).sort((a, b) => b.version - a.version);
  function logout() {
    clearLogin();
    setAuthed(false);
    navigate('/', { replace: true });
  }
  function requireLogin(): boolean {
    if (authed) return true;
    setError('请先登录');
    toast.error('请先登录');
    return false;
  }
  async function generate() {
    if (!prompt.trim() || loading) return;
    if (!requireLogin()) return;
    setLoading(true); setError('');
    try {
      const result = await generateApp(prompt.trim(), isExample ? undefined : config);
      const version = makeVersion(result, prompt.trim());
      setApp(previous => ({ ...previous, versions: isExample ? [version] : [...previous.versions, version], activeVersionId: version.id, updatedAt: version.createdAt }));
      setIsExample(false); setDirty(true); toast.success('应用已生成，试试右侧预览吧。');
    } catch (err) { setError(errorMessage(err)); } finally { setLoading(false); }
  }
  function save() {
    if (!requireLogin()) return;
    const updated = { ...app, updatedAt: new Date().toISOString() };
    const next = [updated, ...library.filter(item => item.id !== app.id)];
    try {
      writeLibrary(next); setLibrary(next); setApp(updated); setDirty(false); setIsExample(false); setSharedMode(false); setVersionLog(rebuildAppVersions(next));
      clearStoredShared();
      try { localStorage.setItem('mini-builder:last', app.id); } catch { /* 应用记录已经保存 */ }
      if (window.location.hash) window.history.replaceState(null, '', window.location.pathname + window.location.search);
      toast.success(sharedMode ? '已保存到我的应用。' : '应用与所有版本已保存到本地。');
    } catch { setError('保存失败：本地存储空间不足或被禁用。当前应用仍保留在页面中，请勿刷新。'); }
  }
  function confirmDiscard() { return !dirty || window.confirm('当前生成的版本尚未保存，确定离开并放弃这些修改吗？'); }
  function openApp(item: SavedApp) {
    if (!requireLogin()) return;
    if (!confirmDiscard()) return;
    setApp(item); setDirty(false); setIsExample(false); setPrompt(''); setError(''); setSharedMode(false);
    clearStoredShared();
    window.history.replaceState(null, '', window.location.pathname);
    try { localStorage.setItem('mini-builder:last', item.id); } catch { notifyStorageError('无法记录上次打开的应用。'); }
  }
  function newApp() {
    if (!confirmDiscard()) return;
    const version = makeVersion(exampleConfig, '内置示例 · 等待生成');
    setApp({ id: crypto.randomUUID(), versions: [version], activeVersionId: version.id, updatedAt: version.createdAt }); setDirty(false); setIsExample(true); setPrompt(''); setError(''); setSharedMode(false);
    clearStoredShared();
    window.history.replaceState(null, '', window.location.pathname);
  }
  function rollbackTo(entry: AppVersionEntry) {
    if (!requireLogin()) return;
    if (!window.confirm('确定要回滚到该版本吗？')) return;
    const snapshot = makeVersion(entry.spec, `回滚到 v${entry.version}`);
    const updated = { ...app, versions: [...app.versions, snapshot], activeVersionId: snapshot.id, updatedAt: new Date().toISOString() };
    const next = [updated, ...library.filter(item => item.id !== app.id)];
    try {
      writeLibrary(next); setLibrary(next); setApp(updated); setDirty(false); setIsExample(false); setSharedMode(false); setVersionLog(rebuildAppVersions(next));
      clearStoredShared();
      if (window.location.hash) window.history.replaceState(null, '', window.location.pathname + window.location.search);
      toast.success(`已回滚到 v${entry.version}`, { position: 'top-center' });
    } catch { setError('回滚失败：本地存储空间不足或被禁用，请重试。'); }
  }
  async function copy(text: string) {
    try { await navigator.clipboard.writeText(text); setCopied(true); toast.success('已复制到剪贴板'); window.setTimeout(() => setCopied(false), 2000); }
    catch { toast.error('剪贴板不可用，请手动选择并复制内容。'); }
  }
  async function handleShare() {
    const url = shareUrl(config);
    try { await navigator.clipboard.writeText(url); toast.success('分享链接已复制'); }
    catch { setShare(url); setCopied(false); toast.error('剪贴板不可用，请在弹窗中手动复制链接'); }
  }
  function dismissShareError() { setSharedInvalid(false); clearStoredShared(); navigate('/', { replace: true }); }
  function handleExport() {
    if (isExample) { toast.error('请先生成一个应用'); return; }
    try {
      exportAppHtml(config);
      toast.success('代码已导出');
      if (!authed) toast.info('登录后可以保存导出历史');
    } catch { toast.error('导出失败，请重试。'); }
  }
  const previewKey = `mini-builder:preview:${JSON.stringify(config)}`;
  return <div className="builder-shell">
    <header className="topbar"><a className="brand" href="/" aria-label="Mini App Builder 首页"><span className="brand-mark"><Box size={22} strokeWidth={1.8} /></span><strong>Mini App Builder</strong><span className="demo-badge">DEMO</span></a><div className="topbar-right"><span className="local-indicator"><span />本地工作空间</span><button className="nav-btn ghost-nav" onClick={handleShare} disabled={loading}><Share2 size={13} />分享</button>{authed ? <><div className="user-chip" title={userEmail}><CircleUserRound size={15} /><span>{userEmail || '演示用户'}</span></div><button className="logout-btn" onClick={logout}><LogOut size={13} />退出登录</button></> : <><Link className="nav-btn primary-nav" to="/login">登录</Link><Link className="nav-btn ghost-nav" to="/register">注册</Link></>}<button className="icon-btn help-button" aria-label="使用说明" onClick={() => setShowHelp(true)}><CircleHelp size={18} /></button></div></header>
    {sharedInvalid ? <div className="share-banner share-error" role="alert"><span className="share-banner-icon"><AlertCircle size={17} /></span><div className="share-banner-text"><b>分享链接无法打开</b><span>链接中的应用参数无效或已损坏，请确认链接是否完整。</span></div><button className="nav-btn ghost-nav" onClick={dismissShareError}>返回主页面</button></div> : sharedMode && <div className="share-banner"><span className="share-banner-icon"><Share2 size={17} /></span><div className="share-banner-text"><b>当前为分享预览模式</b><span>正在预览分享的应用配置，保存后可继续编辑与生成新版本。</span></div><button className="nav-btn primary-nav" onClick={save} disabled={loading}>保存到我的应用</button></div>}
    <div className="intro"><div><div className="eyebrow">从一个想法，到一个应用</div><h1>描述你的想法，剩下的交给 AI<span>。</span></h1><p>生成配置，即时预览。让每个小想法都有自己的舞台。</p></div><div className="flow-hint"><span><Sparkles size={14} />描述需求</span><ArrowRight size={13} /><span><Code2 size={14} />生成配置</span><ArrowRight size={13} /><span><Monitor size={14} />实时预览</span></div></div>
    <main className="workspace">
      <aside className="sidebar panel"><div className="panel-heading"><span><Sparkles size={16} />应用构建</span><button className="icon-btn" aria-label="新建应用" disabled={loading} onClick={newApp}><Plus size={17} /></button></div>
        <section className="prompt-section"><label htmlFor="prompt">你想构建什么？</label><div className="prompt-box"><textarea id="prompt" placeholder={'例如：做一个简洁的待办清单，\n可以添加、完成和删除任务…'} maxLength={2000} value={prompt} disabled={loading} onChange={event => setPrompt(event.target.value)} onKeyDown={event => { if ((event.metaKey || event.ctrlKey) && event.key === 'Enter') { event.preventDefault(); void generate(); } }} /><div className="prompt-meta"><span>自然语言描述</span><span>{prompt.length} / 2000</span></div></div><button className="primary-btn generate-btn" onClick={generate} disabled={loading || prompt.trim().length < 2}>{loading ? <Loader2 size={16} className="spin" /> : <Sparkles size={16} />}{loading ? 'AI 正在构建…' : isExample ? '生成应用' : '生成新版本'}<span>⌘ ↵</span></button><p className="try-label">从一个小想法开始</p><div className="suggestions"><button disabled={loading} onClick={() => setPrompt('做一个简洁的待办清单，使用绿色主题')}><ListTodo size={14} />待办清单<ArrowUpRight size={12} /></button><button disabled={loading} onClick={() => setPrompt('做一个番茄钟，专注25分钟，休息5分钟')}><Timer size={14} />番茄钟<ArrowUpRight size={12} /></button></div><p className="scope-note">MVP 支持待办清单与番茄钟。可描述标题、配色、任务与时长。</p>
        {error && <div className="error-box" role="alert"><span>{error}</span>{error === '请先登录' ? <div className="error-actions"><Link className="error-link" to="/login">去登录</Link><Link className="error-link secondary" to="/register">去注册</Link></div> : <button disabled={loading || prompt.trim().length < 2} onClick={generate}><RotateCcw size={12} />重新尝试</button>}</div>}</section>
        <section className="history-section"><div className="section-label"><span><History size={14} />历史应用</span><span>{library.length.toString().padStart(2, '0')}</span></div><div className="history-list">{authed ? <>{library.map(item => { const current = item.versions.find(version => version.id === item.activeVersionId) || item.versions[0]; const Icon = current.config.type === 'todo' ? ListTodo : Timer; return <button disabled={loading} key={item.id} className={`history-item ${item.id === app.id ? 'active' : ''}`} onClick={() => openApp(item)}><span className="history-icon"><Icon size={17} /></span><span><b>{current.config.name}</b><small>{new Date(item.updatedAt).toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' })} · {item.versions.length} 个版本</small></span><ChevronRight size={13} /></button>; })}{library.length === 0 && <div className="empty-history"><History size={22} /><span>你的应用故事，从这里开始</span><small>保存后即可在这里再次打开</small></div>}</> : <div className="locked-box"><Lock size={20} /><span>登录后可查看保存的应用</span><small>保存与历史仅保存在当前浏览器</small></div>}</div></section>
        <div className="sidebar-footer"><span className="tiny-dot" />数据仅保存在当前浏览器</div>
      </aside>
      <section className="editor panel"><div className="panel-heading"><span><Code2 size={16} />应用配置</span><span className="format-label">JSON</span></div><div className="editor-tabbar"><div><FileJson size={14} /><span>app.config.json</span><span className="tab-dot" /></div><button className="icon-btn" aria-label="复制配置" onClick={() => copy(JSON.stringify(config, null, 2))}>{copied ? <Check size={15} /> : <Copy size={15} />}</button></div><div className="editor-title"><span>{config.name}</span><span>v{versionIndex} <i /> {isExample ? '内置示例' : isSaved ? '已保存' : '未保存'}</span></div><div className="code-area"><JsonEditor config={config} />{loading && <div className="editor-loading"><Loader2 size={20} className="spin" /><b>智能体正在生成配置</b><span>分析需求 → 生成结构 → 校验配置</span><small>完成后将更新预览，请稍候</small></div>}</div><div className="editor-info"><CheckCircle2 size={14} /><span>结构化配置 · 安全渲染</span><span>UTF-8</span></div><div className="config-note"><div className="config-note-icon"><Box size={18} /></div><div><b>配置驱动，无需编写代码</b><p>AI 将你的想法转为结构化配置，预览区即时呈现可交互应用。</p></div></div></section>
      <div className="right-col"><section className="preview panel"><div className="panel-heading"><span><Monitor size={16} />应用预览<span className="live-label"><i />实时</span></span><div className="device-toggle"><button aria-label="桌面端预览" title="桌面端预览" className={device === 'desktop' ? 'active' : ''} onClick={() => setDevice('desktop')}><Monitor size={16} /></button><button aria-label="移动端预览" title="移动端预览" className={device === 'mobile' ? 'active' : ''} onClick={() => setDevice('mobile')}><Smartphone size={16} /></button></div></div><div className="preview-toolbar"><span><span className="tiny-dot" />{isExample ? '示例应用' : sharedMode && !dirty ? '分享应用' : config.name}</span><div><button disabled={loading} onClick={save}><Save size={14} />{isSaved ? '已保存' : '保存'}</button><button disabled={loading} onClick={handleExport}><Download size={14} />导出</button><button disabled={loading} onClick={handleShare}><Share2 size={14} />分享</button></div></div><div className={`preview-canvas ${device}`}><div className="browser-frame"><div className="browser-bar"><div className="browser-dots"><i /><i /><i /></div><span><Box size={11} />mini-app / {config.type}</span><div className="browser-spacer" /></div><div className="rendered-app"><AppPreview key={previewKey} config={config} storageKey={previewKey} onError={notifyStorageError} /></div></div><div className="preview-caption"><CheckCircle2 size={13} />{device === 'mobile' ? '移动视图 · 340 px' : '桌面视图 · 自适应'}<span>试试添加任务或开始计时</span></div></div><div className="preview-bottom"><span>由 Mini App Builder 构建</span><span>想法 → 应用 <Sparkles size={12} /></span></div></section>
        <section className="version-history panel">
          <div className="panel-heading"><span><History size={16} />版本历史</span><span className="format-label">{appVersionEntries.length} 个版本</span></div>
          <div className="version-hint">回滚会创建一个包含所选版本快照的新版本</div>
          <div className="version-history-list">
            {authed ? (appVersionEntries.length > 0 ? appVersionEntries.map(entry => <div className="version-row" key={`${entry.appId}-${entry.version}`}><span className="version-badge">v{entry.version}</span><div className="version-meta"><b title={entry.description}>{entry.description}</b><small>{formatVersionTime(entry.timestamp)}</small></div><button className="rollback-btn" disabled={loading} onClick={() => rollbackTo(entry)}><RotateCcw size={12} />回滚</button></div>) : <div className="empty-history"><History size={22} /><span>暂无版本历史</span><small>保存应用后，版本会记录在这里</small></div>) : <div className="locked-box"><Lock size={20} /><span>登录后可查看版本历史</span><small>版本记录保存在当前浏览器</small></div>}
          </div>
        </section>
      </div>
    </main><footer className="workspace-footer"><span><Box size={12} />Mini App Builder<span className="footer-divider">/</span>把灵感，变成可以使用的东西。</span><span>本地优先 · 配置驱动 · 即时预览</span></footer>
    {(share || showHelp) && <div className="modal-overlay" onClick={() => { setShare(''); setShowHelp(false); }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" onClick={event => event.stopPropagation()}><button className="icon-btn modal-close" aria-label="关闭" onClick={() => { setShare(''); setShowHelp(false); }}><X size={18} /></button><h2 id="modal-title">{share ? '分享你的应用' : '从想法到应用'}</h2>{share ? <><p>链接包含当前版本配置，任何人打开即可使用相同应用。不会分享你的个人任务或计时状态。</p><input autoFocus aria-label="分享链接" readOnly value={share} onFocus={event => event.target.select()} /><button className="primary-btn" onClick={() => copy(share)}>{copied ? <Check size={16} /> : <Copy size={16} />}{copied ? '已复制链接' : '复制分享链接'}</button><small>链接由当前应用配置生成，可在任意浏览器打开。</small></> : <><p>1. 输入需求，或选择待办 / 番茄钟示例。</p><p>2. 点击生成，AI 会生成并校验配置；描述修改需求即可生成新版本。</p><p>3. 在预览里操作，点击保存保留应用及版本。历史和个人操作仅保存在当前浏览器。</p><p>4. 分享链接只携带当前配置，不包含个人数据；其他人无需登录即可预览。</p></>}</section></div>}
  </div>;
}
