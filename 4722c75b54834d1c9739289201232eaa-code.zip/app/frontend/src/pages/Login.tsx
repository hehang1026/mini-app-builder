import { useState, type FormEvent } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { AlertCircle, Box, Info, Loader2, LogIn } from 'lucide-react';
import { DEMO_ACCOUNT, readAuth, saveLogin } from '@/lib/auth';
import BackHomeButton from '@/components/BackHomeButton';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  if (readAuth().isLogin) return <Navigate to="/" replace />;

  function submit(event: FormEvent) {
    event.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    setError('');
    window.setTimeout(() => {
      if (email.trim().toLowerCase() === DEMO_ACCOUNT.email && password === DEMO_ACCOUNT.password) {
        saveLogin(DEMO_ACCOUNT.email);
        navigate('/', { replace: true });
        return;
      }
      setError('账号或密码错误');
      setSubmitting(false);
    }, 500);
  }

  return (
    <div className="login-shell">
      <BackHomeButton />
      <div className="login-brand"><span className="brand-mark"><Box size={22} strokeWidth={1.8} /></span><strong>Mini App Builder</strong></div>
      <main className="login-card">
        <h1>登录到你的工作台</h1>
        <p className="login-sub">输入演示账号，继续构建你的小应用。</p>
        {error && <div className="login-error" role="alert"><AlertCircle size={15} />{error}</div>}
        <form onSubmit={submit}>
          <div className="login-field">
            <label className="field-label" htmlFor="login-email">邮箱</label>
            <input id="login-email" className="login-input" type="email" autoComplete="email" placeholder="you@example.com" value={email} disabled={submitting} onChange={event => setEmail(event.target.value)} />
          </div>
          <div className="login-field">
            <label className="field-label" htmlFor="login-password">密码</label>
            <input id="login-password" className="login-input" type="password" autoComplete="current-password" placeholder="请输入密码" value={password} disabled={submitting} onChange={event => setPassword(event.target.value)} />
          </div>
          <button className="primary-btn login-submit" type="submit" disabled={submitting}>{submitting ? <Loader2 size={16} className="spin" /> : <LogIn size={16} />}{submitting ? '登录中…' : '登录'}</button>
        </form>
        <div className="demo-hint"><Info size={14} /><span>演示账号：test@atoms-demo.com / Demo123456</span></div>
      </main>
      <p className="login-footer">本地演示登录 · 仅用于当前浏览器</p>
    </div>
  );
}
