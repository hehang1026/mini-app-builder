import json
import logging
from fastapi import HTTPException
from pydantic import BaseModel, Field
from typing import Literal
from services.aihub import AIHubService
from schemas.aihub import GenTxtRequest, ChatMessage


class AppConfig(BaseModel):
    schemaVersion: Literal[1]
    type: Literal['todo', 'pomodoro']
    name: str = Field(min_length=1, max_length=40)
    description: str = Field(min_length=1, max_length=160)
    accent: str = Field(pattern=r'^#[0-9a-fA-F]{6}$')
    tasks: list[str] = Field(max_length=12)
    focusMinutes: int = Field(ge=1, le=120)
    breakMinutes: int = Field(ge=1, le=60)
    buttonLabel: str = Field(min_length=1, max_length=24)


SYSTEM_PROMPT = '''你是 Mini App Builder 的应用配置设计智能体。仅支持 todo（待办清单）与 pomodoro（番茄钟）。
根据用户需求生成定制中文标题、说明、按钮、配色、初始任务或计时时长；保留用户明确指定的值。
如果用户要求其他应用或未支持的功能（登录、联网、支付、复杂多页、闹钟声音等），返回 {"unsupported": true, "message": "中文说明当前仅支持的能力"}，不要假装实现。
只输出一个 JSON 对象，不含 Markdown。正常配置所有字段必须存在：
{"schemaVersion":1,"type":"todo","name":"今日待办","description":"把想做的事，一件件完成。","accent":"#21836B","tasks":["规划今天的重点","完成第一项任务"],"focusMinutes":25,"breakMinutes":5,"buttonLabel":"添加任务"}
name 最多40字，description最多160字，buttonLabel最多24字，tasks最多12个字符串每项最多120字，accent为6位hex。focusMinutes为1至120整数，breakMinutes为1至60整数。
todo提供添加、完成、编辑、删除和筛选；pomodoro提供专注/休息切换、开始、暂停、重置。不要输出代码。''' 


def parse_config(raw: str) -> AppConfig:
    start, end = raw.find('{'), raw.rfind('}')
    if start < 0 or end <= start:
        raise ValueError('没有有效的 JSON 对象')
    data = json.loads(raw[start:end + 1])
    if data.get('unsupported') is True:
        raise HTTPException(status_code=422, detail=str(data.get('message', '当前仅支持待办清单和番茄钟。'))[:240])
    config = AppConfig.model_validate(data)
    if any(not task.strip() or len(task) > 120 for task in config.tasks):
        raise ValueError('任务长度不符合要求')
    return config


async def generate_config(prompt: str, current: AppConfig | None) -> AppConfig:
    service = AIHubService()
    context = f'当前配置：{current.model_dump_json()}\n在此基础上修改。\n' if current else ''
    messages = [ChatMessage(role='system', content=SYSTEM_PROMPT), ChatMessage(role='user', content=context + '需求：' + prompt)]
    for attempt in range(2):
        try:
            response = await service.gentxt(GenTxtRequest(messages=messages, model='gpt-5.4', stream=False))
        except Exception as exc:
            logging.exception('配置生成服务失败')
            raise HTTPException(status_code=503, detail='AI 生成服务暂时不可用，请稍后重试。') from exc
        try:
            return parse_config(response.content.strip())
        except HTTPException:
            raise
        except (ValueError, TypeError, AttributeError) as exc:
            if attempt == 1:
                raise HTTPException(status_code=502, detail='生成配置未通过校验，请重试或简化需求。') from exc
            messages.extend([ChatMessage(role='assistant', content=response.content), ChatMessage(role='user', content='配置未通过校验，请按照规定字段和范围修复，仅返回 JSON。')])
    raise HTTPException(status_code=502, detail='生成失败，请重试。')
