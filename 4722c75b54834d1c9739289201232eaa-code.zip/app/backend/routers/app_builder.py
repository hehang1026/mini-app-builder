from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from services.app_builder import AppConfig, generate_config

router = APIRouter(prefix='/api/v1/builder', tags=['builder'])


class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=2, max_length=2000)
    current: AppConfig | None = None


class GenerateResponse(BaseModel):
    config: AppConfig


@router.post('/generate', response_model=GenerateResponse)
async def generate(data: GenerateRequest):
    if len(data.prompt.strip()) < 2:
        raise HTTPException(status_code=422, detail='请描述你想创建的应用。')
    return GenerateResponse(config=await generate_config(data.prompt.strip(), data.current))
