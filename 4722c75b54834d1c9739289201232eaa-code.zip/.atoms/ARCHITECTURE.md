---
last_updated: 2026-10-28T09:07:08Z
---

# Architecture Design

## System Overview
Mini App Builder：React 三栏工作台 + Atoms Cloud 配置生成 API；无需数据库与登录。应用/版本/个人预览状态由 localStorage 保存，分享 URL hash 携带经校验配置。

## Tech Stack

## Module Design
| Module | Responsibility | Key Files |
|--------|---------------|-----------|
| 配置协议与客户端 | Zod 校验、SDK API、localStorage、#/share?app= base64 分享与会话恢复 | frontend/src/lib/builder.ts |
| 工作台 | 需求、错误重试、历史、版本、保存与分享 | frontend/src/pages/Index.tsx |
| 安全预览 | 待办增改删/完成/筛选与本地状态、截止时间驱动番茄钟 | frontend/src/components/AppPreview.tsx |
| AI API | gpt-5.4 非流式输出、Pydantic 校验、一次修复、明确失败 | backend/services/app_builder.py、backend/routers/app_builder.py |

## Tech Decisions
| Decision | Choice | Rationale |
|----------|--------|-----------|

## File Tree Plan

## Implementation Guide

